<?php
$con=mysqli_connect("localhost","root","","ams") or die("DB not Connected");
?>