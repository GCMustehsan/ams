<!DOCTYPE html>
<html>
<head>

	<title>Attendance Management System</title>
	<link rel="stylesheet" type="text/css" href="style.css">


</head>

<body>
	<center>

<header>

  <h1>Attendance Management System</h1>
  </header>
</center>
<br><br>
<div class="container">
  <h2>login as!</h2>
    <a href="login.php"><button id="button" type="button" >User</button></a>
    <a href="admin/login.php"><button id="button1" type="button" >Admin</button></a>
</div>
  </body>
</html>